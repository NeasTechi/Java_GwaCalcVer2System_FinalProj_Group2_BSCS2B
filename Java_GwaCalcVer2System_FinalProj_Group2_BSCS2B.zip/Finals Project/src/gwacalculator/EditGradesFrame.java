package gwacalculator;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.ArrayList;

public class EditGradesFrame extends JFrame {

    private String studentId;
    private String studentName;
    private AdminDashboard admin;

    public EditGradesFrame(String studentId, String studentName, AdminDashboard admin) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.admin = admin;

        // Frame setup
        setTitle("Edit Grades - " + studentName);
        setSize(400, 500);
        setLocationRelativeTo(null);
        setLayout(null);
        setResizable(false);

        // Panel for grades inside scroll pane
        JPanel gradesPanel = new JPanel(null);
        gradesPanel.setBackground(new Color(255, 228, 225));

        JScrollPane scrollPane = new JScrollPane(gradesPanel);
        scrollPane.setBounds(10, 10, 360, 380);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        add(scrollPane);

        ArrayList<JTextField> gradeFields = new ArrayList<>();
        ArrayList<JTextField> unitFields = new ArrayList<>();

        // Load existing subjects
        String query = "SELECT id, grade, units FROM subjects WHERE student_user_identifier = ?";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, studentId);
            ResultSet rs = ps.executeQuery();
            int y = 10;

            while (rs.next()) {
                gradesPanel.setPreferredSize(new Dimension(360, gradeFields.size() * 40 + 20));
                JLabel subjectLabel = new JLabel("Subject " + rs.getInt("id") + ":");
                subjectLabel.setBounds(10, y, 80, 25);
                gradesPanel.add(subjectLabel);

                JTextField gradeField = new JTextField(String.valueOf(rs.getDouble("grade")));
                gradeField.setBounds(100, y, 50, 25);
                gradesPanel.add(gradeField);

                JTextField unitField = new JTextField(String.valueOf(rs.getDouble("units")));
                unitField.setBounds(160, y, 50, 25);
                gradesPanel.add(unitField);

                gradeFields.add(gradeField);
                unitFields.add(unitField);

                y += 40;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading grades: " + e.getMessage());
            return;
        }

        // Button to add new subject
        JButton addSubjectBtn = new JButton("+ Add Subject");
        addSubjectBtn.setBounds(10, 400, 150, 30);
        addSubjectBtn.addActionListener(e -> {
            int y = gradeFields.size() * 40 + 10;

            JTextField gradeField = new JTextField();
            gradeField.setBounds(100, y, 50, 25);
            gradesPanel.add(gradeField);

            JTextField unitField = new JTextField();
            unitField.setBounds(160, y, 50, 25);
            gradesPanel.add(unitField);

            gradeFields.add(gradeField);
            unitFields.add(unitField);

            // Adjust panel size for scrolling
            gradesPanel.setPreferredSize(new Dimension(360, y + 50));
            gradesPanel.revalidate();
            gradesPanel.repaint();
        });
        add(addSubjectBtn);

        // Button to save changes
        JButton saveBtn = new JButton("Save");
        saveBtn.setBounds(200, 400, 150, 30);
        saveBtn.addActionListener(e -> {
            try (Connection conn = Database.connect()) {
                // Delete old subjects
                PreparedStatement delete = conn.prepareStatement("DELETE FROM subjects WHERE student_user_identifier = ?");
                delete.setString(1, studentId);
                delete.executeUpdate();

                // Insert new/edited subjects
                PreparedStatement insert = conn.prepareStatement(
                        "INSERT INTO subjects(student_user_identifier, grade, units) VALUES(?, ?, ?)");
                for (int i = 0; i < gradeFields.size(); i++) {
                    String g = gradeFields.get(i).getText().trim();
                    String u = unitFields.get(i).getText().trim();
                    if (g.isEmpty() || u.isEmpty()) continue;
                    insert.setString(1, studentId);
                    insert.setDouble(2, Double.parseDouble(g));
                    insert.setDouble(3, Double.parseDouble(u));
                    insert.executeUpdate();
                    updateStudentGWA(conn);
                }
                JOptionPane.showMessageDialog(this, "Grades saved successfully!");
                dispose();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Failed to save grades: " + ex.getMessage());
            }
        });
        add(saveBtn);

        setVisible(true);
    }
    
    private void updateStudentGWA(Connection conn) throws SQLException {

    String sql = 
        "SELECT SUM(grade * units) AS total, " +
        "SUM(units) AS units " +
        "FROM subjects " +
        "WHERE student_user_identifier = ?";

    double gwa = 0;

    try (PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, studentId);
        ResultSet rs = ps.executeQuery();

        if (rs.next() && rs.getDouble("units") > 0) {
            gwa = rs.getDouble("total") / rs.getDouble("units");
            gwa = Math.round(gwa * 100.0) / 100.0;
        }
    }

    PreparedStatement update = conn.prepareStatement(
        "UPDATE students SET gwa = ?, date = datetime('now') WHERE user_identifier = ?"
    );
    update.setDouble(1, gwa);
    update.setString(2, studentId);
    update.executeUpdate();
    }
}
