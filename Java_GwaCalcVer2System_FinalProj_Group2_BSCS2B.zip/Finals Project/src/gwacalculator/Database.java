package gwacalculator;

import java.sql.*;

public class Database {

    private static final String URL = "jdbc:sqlite:gwa.db";

    // Connect to database
    public static Connection connect() {
        try {
            Connection conn = DriverManager.getConnection(URL);
            System.out.println("Connected to SQLite: " + URL);
            return conn;
        } catch (SQLException e) {
            System.out.println("DB Connection Error: " + e.getMessage());
            return null;
        }
    }

    // Initialize tables
    public static void initialize() {
        String usersTable = "CREATE TABLE IF NOT EXISTS users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_identifier TEXT UNIQUE, " +
                "name TEXT, " +
                "password TEXT, " +
                "role TEXT" + // 'admin' or 'student'
                ");";

        String studentsTable = "CREATE TABLE IF NOT EXISTS students (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_identifier TEXT UNIQUE, " + // same as users.user_identifier
                "name TEXT, " +
                "gwa REAL, " +
                "date TEXT, " +
                "FOREIGN KEY(user_identifier) REFERENCES users(user_identifier)" +
                ");";

        String subjectsTable = "CREATE TABLE IF NOT EXISTS subjects (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "student_user_identifier TEXT, " +
                "grade REAL, " +
                "units REAL, " +
                "FOREIGN KEY(student_user_identifier) REFERENCES users(user_identifier)" +
                ");";

        try (Connection conn = connect();
             Statement stmt = conn.createStatement()) {
            stmt.execute(usersTable);
            stmt.execute(studentsTable);
            stmt.execute(subjectsTable);
            System.out.println("Tables initialized successfully!");
        } catch (SQLException e) {
            System.out.println("Initialization Error: " + e.getMessage());
        }
    }

    // Check if user exists
    public static boolean userExists(String userId) {
        String query = "SELECT id FROM users WHERE user_identifier = ?";
        try (Connection conn = connect();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, userId);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Add user
    public static void addUser(String userId, String name, String password, String role) {
        String query = "INSERT INTO users(user_identifier, name, password, role) VALUES(?, ?, ?, ?)";
        try (Connection conn = connect();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, userId);
            ps.setString(2, name);
            ps.setString(3, password);
            ps.setString(4, role);
            ps.executeUpdate();
            System.out.println("User added: " + userId);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Add student record
    public static int addStudentRecord(String userId, String name) {
        String query = "INSERT INTO students(user_identifier, name, gwa, date) VALUES(?, ?, 0, datetime('now'))";
        try (Connection conn = connect();
             PreparedStatement ps = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, userId);
            ps.setString(2, name);
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }
}
