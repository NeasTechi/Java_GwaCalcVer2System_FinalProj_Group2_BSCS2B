package gwacalculator;

import javax.swing.*;
import java.awt.*;

public class MainMenu extends JFrame {

    public MainMenu() {
        setTitle("Welcome");
        setBounds(450, 190, 1014, 597);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel contentPane = new JPanel(null);
        contentPane.setBackground(new Color(255, 255, 255));
        setContentPane(contentPane);

        // Rounded gradient header
        GradientHeader header = new GradientHeader();
        header.setBounds(20, 10, 960, 70);
        JLabel hdrLabel = new JLabel("GWA CALCULATOR SYSTEM");
        hdrLabel.setFont(new Font("Serif", Font.BOLD, 28));
        hdrLabel.setHorizontalAlignment(SwingConstants.CENTER);
        hdrLabel.setForeground(Color.BLACK);
        hdrLabel.setBounds(0, 0, 960, 70);
        header.setLayout(null);
        header.add(hdrLabel);
        contentPane.add(header);

        JLabel welcomeLabel = new JLabel("Welcome to GWA Calculator");
        welcomeLabel.setBounds(200, 140, 600, 50);
        welcomeLabel.setFont(new Font("Serif", Font.BOLD, 32));
        welcomeLabel.setHorizontalAlignment(JLabel.CENTER);
        contentPane.add(welcomeLabel);

        JLabel subtitleLabel = new JLabel("Please login or register to continue");
        subtitleLabel.setBounds(200, 200, 600, 40);
        subtitleLabel.setFont(new Font("Serif", Font.PLAIN, 20));
        subtitleLabel.setHorizontalAlignment(JLabel.CENTER);
        contentPane.add(subtitleLabel);

        RoundedButton loginButton = new RoundedButton("LOGIN", new Color(255, 182, 193));
        loginButton.setFont(new Font("Serif", Font.BOLD, 20));
        loginButton.setBounds(300, 300, 180, 60);
        loginButton.addActionListener(e -> {
            UserLogin loginFrame = new UserLogin(this);
            loginFrame.setVisible(true);
            this.setVisible(false);
        });
        contentPane.add(loginButton);

        RoundedButton registerButton = new RoundedButton("REGISTER", new Color(173, 216, 230));
        registerButton.setFont(new Font("Serif", Font.BOLD, 20));
        registerButton.setBounds(520, 300, 180, 60);
        registerButton.addActionListener(e -> {
            UserRegistration registerFrame = new UserRegistration(this);
            registerFrame.setVisible(true);
            this.setVisible(false);
        });
        contentPane.add(registerButton);
    }

    public static void main(String[] args) {
        gwacalculator.Database.initialize(); // initialize DB
        EventQueue.invokeLater(() -> {
            try {
                MainMenu menu = new MainMenu();
                menu.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    // Gradient header panel with rounded corners
    private class GradientHeader extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth();
            int h = getHeight();
            GradientPaint gp = new GradientPaint(0, 0, new Color(255, 182, 193), w, 0, new Color(173, 216, 230));
            g2.setPaint(gp);
            g2.fillRoundRect(0, 0, w, h, 15, 15);
            g2.setColor(Color.BLACK);
            g2.setStroke(new BasicStroke(2));
            g2.drawRoundRect(0, 0, w - 1, h - 1, 15, 15);
        }
    }

    // Custom rounded button with gradient fill
    private class RoundedButton extends JButton {
        private final Color baseColor;

        RoundedButton(String text, Color baseColor) {
            super(text);
            this.baseColor = baseColor;
            setContentAreaFilled(false);
            setFocusPainted(false);
            setBorderPainted(false);
            setForeground(Color.BLACK);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth();
            int h = getHeight();
            GradientPaint gp = new GradientPaint(0, 0, baseColor.darker(), w, h, baseColor.brighter());
            g2.setPaint(gp);
            g2.fillRoundRect(0, 0, w, h, h / 2, h / 2);
            g2.setColor(Color.BLACK);
            g2.setStroke(new BasicStroke(2));
            g2.drawRoundRect(0, 0, w - 1, h - 1, h / 2, h / 2);
            g2.dispose();
            super.paintComponent(g);
        }

        @Override
        public boolean isOpaque() {
            return false;
        }
    }
}
