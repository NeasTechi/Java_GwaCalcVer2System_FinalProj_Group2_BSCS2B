package gwacalculator;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class ChangePassword extends JFrame {

    private JPasswordField passwordField;

    public ChangePassword(String userId) {
        setTitle("Change Password");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(450, 190, 1014, 597);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel contentPane = new JPanel(null);
        contentPane.setBackground(new Color(255, 255, 255));
        setContentPane(contentPane);

        // header to match app theme
        GradientHeader header = new GradientHeader();
        header.setBounds(20, 10, 960, 70);
        JLabel hdrLabel = new JLabel("GWA CALCULATOR SYSTEM");
        hdrLabel.setFont(new Font("Serif", Font.BOLD, 28));
        hdrLabel.setHorizontalAlignment(SwingConstants.CENTER);
        hdrLabel.setForeground(Color.BLACK);
        hdrLabel.setBounds(0, 0, 960, 70);
        header.setLayout(null);
        header.add(hdrLabel);
        contentPane.add(header);

        JLabel lblEnterNewPassword = new JLabel("Enter New Password :");
        lblEnterNewPassword.setFont(new Font("Serif", Font.BOLD, 26));
        lblEnterNewPassword.setBounds(80, 120, 300, 40);
        contentPane.add(lblEnterNewPassword);

        passwordField = new JPasswordField();
        passwordField.setFont(new Font("Serif", Font.PLAIN, 20));
        passwordField.setBounds(380, 125, 500, 36);
        passwordField.setOpaque(false);
        passwordField.setBorder(BorderFactory.createMatteBorder(0, 0, 3, 0, Color.BLACK));
        contentPane.add(passwordField);

        RoundedButton btnEnter = new RoundedButton("ENTER", new Color(173, 216, 230));
        btnEnter.setFont(new Font("Serif", Font.BOLD, 20));
        btnEnter.addActionListener((ActionEvent e) -> changePasswordAction(userId));

        RoundedButton backButton = new RoundedButton("BACK", new Color(255, 182, 193));
        backButton.setFont(new Font("Serif", Font.BOLD, 20));
        backButton.addActionListener(e -> dispose());

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 30, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.setBounds(20, 200, 960, 80);
        buttonPanel.add(backButton);
        buttonPanel.add(btnEnter);
        contentPane.add(buttonPanel);
    }

    private void changePasswordAction(String userId) {
        String newPassword = new String(passwordField.getPassword()).trim();
        if (newPassword.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Password cannot be empty");
            return;
        }

        String updateQuery = "UPDATE users SET password=? WHERE user_identifier=?";
        try (Connection con = Database.connect();
             PreparedStatement ps = con.prepareStatement(updateQuery)) {

            ps.setString(1, newPassword);
            ps.setString(2, userId);
            int updated = ps.executeUpdate();

            if (updated > 0) {
                JOptionPane.showMessageDialog(this, "Password has been successfully changed");
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to update password");
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage());
        }
    }

    // Rounded gradient header panel
    private static class GradientHeader extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth();
            int h = getHeight();
            GradientPaint gp = new GradientPaint(0, 0, new Color(255, 182, 193), w, 0, new Color(173, 216, 230));
            g2.setPaint(gp);
            g2.fillRoundRect(0, 0, w, h, h, h);
            g2.setColor(Color.BLACK);
            g2.setStroke(new BasicStroke(2));
            g2.drawRoundRect(0, 0, w - 1, h - 1, h, h);
        }
    }

    // Simple rounded button with flat gradient fill
    private static class RoundedButton extends JButton {
        private final Color base;
        RoundedButton(String text, Color base) {
            super(text);
            this.base = base;
            setContentAreaFilled(false);
            setFocusPainted(false);
            setBorderPainted(false);
            setForeground(Color.BLACK);
        }
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth();
            int h = getHeight();
            GradientPaint gp = new GradientPaint(0, 0, base.darker(), w, h, base.brighter());
            g2.setPaint(gp);
            g2.fillRoundRect(0, 0, w, h, h/2, h/2);
            g2.setColor(Color.BLACK);
            g2.setStroke(new BasicStroke(2));
            g2.drawRoundRect(0, 0, w-1, h-1, h/2, h/2);
            g2.dispose();
            super.paintComponent(g);
        }
        @Override
        public boolean isOpaque() { return false; }
    }
}
