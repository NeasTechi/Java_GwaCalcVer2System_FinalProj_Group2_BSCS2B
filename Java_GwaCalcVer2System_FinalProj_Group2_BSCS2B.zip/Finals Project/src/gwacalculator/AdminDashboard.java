package gwacalculator;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.ArrayList;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class AdminDashboard extends JFrame {

    private JTable studentTable;
    private String adminId; // store logged-in admin ID

    public AdminDashboard(String adminId) {
        this.adminId = adminId;

        setTitle("Admin Dashboard");
        setBounds(450, 190, 1014, 597);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(173, 216, 230));
        setLayout(new BorderLayout(10, 10));

        createTopPanel();
        createStudentTable();
        createBottomButtons();
        loadStudentTable();

        setVisible(true);
    }

    // ------------------ TOP PANEL ------------------
    private void createTopPanel() {
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(new Color(255, 255, 255));
        topPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 0, 10));

        GradientHeader header = new GradientHeader();
        header.setPreferredSize(new Dimension(400, 70));
        JLabel hdrLabel = new JLabel("ADMIN DASHBOARD");
        hdrLabel.setFont(new Font("Serif", Font.BOLD, 24));
        hdrLabel.setHorizontalAlignment(SwingConstants.CENTER);
        hdrLabel.setForeground(Color.BLACK);
        hdrLabel.setBounds(0, 0, 400, 70);
        header.setLayout(null);
        header.add(hdrLabel);

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 10));
        left.setOpaque(false);
        left.add(header);
        topPanel.add(left, BorderLayout.WEST);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        right.setOpaque(false);
        RoundedButton changePasswordButton = new RoundedButton("Change Password", new Color(255, 182, 193));
        changePasswordButton.setFont(new Font("Serif", Font.BOLD, 14));
        changePasswordButton.addActionListener(e -> {
            ChangePassword cp = new ChangePassword(adminId);
            cp.setTitle("Change Password");
            cp.setVisible(true);
        });

        RoundedButton logOutButton = new RoundedButton("Logout", new Color(173, 216, 230));
        logOutButton.setFont(new Font("Serif", Font.BOLD, 14));
        logOutButton.addActionListener(e -> {
            dispose();
            new MainMenu().setVisible(true);
        });

        right.add(changePasswordButton);
        right.add(logOutButton);
        topPanel.add(right, BorderLayout.EAST);

        add(topPanel, BorderLayout.NORTH);
    }

    // ---------------- STUDENT TABLE ----------------
    private void createStudentTable() {
        studentTable = new JTable();
        JScrollPane scrollPane = new JScrollPane(studentTable);
        add(scrollPane, BorderLayout.CENTER);
    }

    private void createBottomButtons() {
        JPanel bottomPanel = new JPanel(new GridLayout(1, 4, 10, 10));
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        bottomPanel.setBackground(new Color(255, 255, 255));

        RoundedButton addStudentBtn = new RoundedButton("Add Student", new Color(173, 216, 230));
        addStudentBtn.setFont(new Font("Serif", Font.BOLD, 16));
        addStudentBtn.addActionListener(e -> addStudent());

        RoundedButton editStudentBtn = new RoundedButton("Edit Grades", new Color(255, 182, 193));
        editStudentBtn.setFont(new Font("Serif", Font.BOLD, 16));
        editStudentBtn.addActionListener(e -> editGrades());

        RoundedButton deleteStudentBtn = new RoundedButton("Delete Student", new Color(255, 182, 193));
        deleteStudentBtn.setFont(new Font("Serif", Font.BOLD, 16));
        deleteStudentBtn.addActionListener(e -> deleteStudent());

        RoundedButton exportBtn = new RoundedButton("Export Records", new Color(173, 216, 230));
        exportBtn.setFont(new Font("Serif", Font.BOLD, 16));
        exportBtn.addActionListener(e -> exportStudentRecords());

        bottomPanel.add(addStudentBtn);
        bottomPanel.add(editStudentBtn);
        bottomPanel.add(deleteStudentBtn);
        bottomPanel.add(exportBtn);

        add(bottomPanel, BorderLayout.SOUTH);
    }

    // ---------------- LOAD TABLE ----------------
    private void loadStudentTable() {
        String query = "SELECT user_identifier, name, date FROM students";

        try (Connection conn = Database.connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            ArrayList<Object[]> data = new ArrayList<>();
            while (rs.next()) {
                String studentId = rs.getString("user_identifier");
                String name = rs.getString("name");
                String date = rs.getString("date");
                double gwa = computeGWA(studentId);
                data.add(new Object[]{studentId, name, String.format("%.2f", gwa), date});
            }

            String[] columns = {"Student ID", "Name", "GWA", "Date"};
            Object[][] tableData = data.toArray(new Object[0][]);
            studentTable.setModel(new javax.swing.table.DefaultTableModel(tableData, columns));

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading students: " + e.getMessage());
        }
    }

    // ---------------- COMPUTE GWA ----------------
    public double computeGWA(String studentId) {
        double total = 0, units = 0;
        String query = "SELECT grade, units FROM subjects WHERE student_user_identifier=?";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, studentId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                double grade = rs.getDouble("grade");
                double u = rs.getDouble("units");
                total += grade * u;
                units += u;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return units == 0 ? 0 : Math.round(total / units * 100.0) / 100.0;
    }

    // ---------------- ADD STUDENT ----------------
    private void addStudent() {
        JTextField userIdField = new JTextField();
        JTextField nameField = new JTextField();
        Object[] fields = {
                "Student ID:", userIdField,
                "Name:", nameField
        };
        int option = JOptionPane.showConfirmDialog(this, fields, "Add Student", JOptionPane.OK_CANCEL_OPTION);

        if (option == JOptionPane.OK_OPTION) {
            String studentId = userIdField.getText().trim();
            String name = nameField.getText().trim();
            if (studentId.isEmpty() || name.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Student ID and Name cannot be empty!");
                return;
            }

            int result = Database.addStudentRecord(studentId, name);
            if (result != -1) {
                editGrades(studentId, name);
                loadStudentTable();
            }
        }
    }

    // ---------------- EDIT GRADES ----------------
    private void editGrades() {
        int row = studentTable.getSelectedRow();
        if (row != -1) {
            String studentId = (String) studentTable.getValueAt(row, 0);
            String studentName = (String) studentTable.getValueAt(row, 1);
            editGrades(studentId, studentName);
        } else {
            JOptionPane.showMessageDialog(this, "Select a student first!");
        }
    }

    private void editGrades(String studentId, String studentName) {
        new EditGradesFrame(studentId, studentName, this);
    }

    // ---------------- DELETE STUDENT ----------------
    private void deleteStudent() {
        int row = studentTable.getSelectedRow();
        if (row != -1) {
            String studentId = (String) studentTable.getValueAt(row, 0);
            int confirm = JOptionPane.showConfirmDialog(this, "Delete this student?", "Confirm", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                try (Connection conn = Database.connect()) {
                    PreparedStatement ps1 = conn.prepareStatement("DELETE FROM subjects WHERE student_id=?");
                    ps1.setString(1, studentId);
                    ps1.executeUpdate();

                    PreparedStatement ps2 = conn.prepareStatement("DELETE FROM students WHERE user_identifier=?");
                    ps2.setString(1, studentId);
                    ps2.executeUpdate();

                    JOptionPane.showMessageDialog(this, "Student deleted successfully!");
                    loadStudentTable();
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(this, "Failed to delete student: " + e.getMessage());
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Select a student first!");
        }
    }

    // ---------------- EXPORT RECORDS ----------------
    private void exportStudentRecords() {
        String filePath = "admin_student_records.txt";

        try (Connection conn = Database.connect()) {
            String query = "SELECT user_identifier, name, date FROM students ORDER BY date DESC";
            ArrayList<String[]> rows = new ArrayList<>();
            int idW = "Student ID".length();
            int nameW = "Name".length();
            int gwaW = "GWA".length();
            int dateW = "Date".length();

            try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
                while (rs.next()) {
                    String studentId = rs.getString("user_identifier");
                    String name = rs.getString("name");
                    String date = rs.getString("date");

                    String idStr = studentId == null ? "" : studentId;
                    String nameStr = name == null ? "" : name;
                    double gwaVal = computeGWA(idStr);
                    String gwaStr = String.format("%.2f", gwaVal);
                    String dateStr = date == null ? "" : date;

                    rows.add(new String[]{idStr, nameStr, gwaStr, dateStr});

                    idW = Math.max(idW, idStr.length());
                    nameW = Math.max(nameW, nameStr.length());
                    gwaW = Math.max(gwaW, gwaStr.length());
                    dateW = Math.max(dateW, dateStr.length());
                }
            }

            String fmt = String.format("%%-%ds  %%-%ds  %%-%ds  %%-%ds%n", idW, nameW, gwaW, dateW);

            try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
                writer.write(String.format(fmt, "Student ID", "Name", "GWA", "Date"));
                writer.write(String.format(fmt, repeatChar('-', idW), repeatChar('-', nameW), repeatChar('-', gwaW), repeatChar('-', dateW)));
                for (String[] r : rows) writer.write(String.format(fmt, r[0], r[1], r[2], r[3]));
            }

            JOptionPane.showMessageDialog(this,
                    "Student records exported successfully to " + filePath,
                    "Export Complete",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (IOException | SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Export failed: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private String repeatChar(char c, int count) {
        if (count <= 0) return "";
        StringBuilder sb = new StringBuilder(count);
        for (int i = 0; i < count; i++) sb.append(c);
        return sb.toString();
    }

    // ---------------- UI HELPERS ----------------
    private class GradientHeader extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth();
            int h = getHeight();
            GradientPaint gp = new GradientPaint(0, 0, new Color(255, 182, 193), w, 0, new Color(173, 216, 230));
            g2.setPaint(gp);
            g2.fillRoundRect(0, 0, w, h, 15, 15);
            g2.setColor(Color.BLACK);
            g2.setStroke(new BasicStroke(2));
            g2.drawRoundRect(0, 0, w - 1, h - 1, 15, 15);
        }
    }

    private class RoundedButton extends JButton {
        private final Color baseColor;

        RoundedButton(String text, Color baseColor) {
            super(text);
            this.baseColor = baseColor;
            setContentAreaFilled(false);
            setFocusPainted(false);
            setBorderPainted(false);
            setForeground(Color.BLACK);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth();
            int h = getHeight();
            GradientPaint gp = new GradientPaint(0, 0, baseColor.darker(), w, h, baseColor.brighter());
            g2.setPaint(gp);
            g2.fillRoundRect(0, 0, w, h, h / 2, h / 2);
            g2.setColor(Color.BLACK);
            g2.setStroke(new BasicStroke(2));
            g2.drawRoundRect(0, 0, w - 1, h - 1, h / 2, h / 2);
            g2.dispose();
            super.paintComponent(g);
        }

        @Override
        public boolean isOpaque() {
            return false;
        }
    }
}
