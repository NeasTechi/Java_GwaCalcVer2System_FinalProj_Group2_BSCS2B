package gwacalculator;

// Import AWT (Abstract Window Toolkit) classes for GUI components, layouts, and colors.
import java.awt.*;
import java.util.ArrayList;
import javax.swing.*;
import java.sql.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;


public class GwaCalculator extends JFrame {
    
    // -------------------- CONSTANTS AND VARIABLES -------------------- //

    private static final int MAX_FIELDS = 12;   // Max number of subjects allowed.
    private int initialFieldCount = 4;          // Default number of visible input rows.

    // GUI Components
    private JButton calculateButton, addFieldButton, minusButton, clearButton, exportButton, viewButton, deleteButton, logOutButton, changePasswordButton;
    private JButton disclaimerLink;
    private JPanel gradeUnitPanel, mainPanel, centerPanel;
    private JLabel gradeLabel, unitLabel, infoLabel;
    private JTextField nameField;
    private MainMenu mainMenu;
    private String userId;

    // Lists to store text fields dynamically.
    private final ArrayList<JTextField> gradeFields = new ArrayList<>();
    private final ArrayList<JTextField> unitFields = new ArrayList<>();
    private final ArrayList<JTextField> addedGradeFields = new ArrayList<>();
    private final ArrayList<JTextField> addedUnitFields = new ArrayList<>();
    
    
    // -------------------- CONSTRUCTOR -------------------- //

    /**
     * Constructor initializes the entire UI and its components.
     */

    public GwaCalculator(String userId, MainMenu menu) {
        this.userId = userId;
        this.mainMenu = menu;
        initializeUI();
        createMainPanel();
        
        createNameField();       
        createDisclaimerLink();
        String userName = fetchNameFromDB(userId);
            if (userName != null) {
                nameField.setText(userName);
                nameField.setEditable(false);
            } else {
                nameField.setText("Enter your Name: ");
                nameField.setEditable(true);
                nameField.addMouseListener(new java.awt.event.MouseAdapter() {
                    @Override
                    public void mouseClicked(java.awt.event.MouseEvent evt) {
                        if (nameField.getText().equals("Enter your Name: ")) {
                            nameField.setText("");
                        }
                    }
                });
            }
        

        createCalculateButton();
        createPanel();
        createLabels();
        createTextFields();
        loadSubjectsFromDB();
        
        dataPanel();
        
        createExtraFieldButton();
        createClearButton();
        createMinusButton();
        createExportButton();
        createViewButton();
        createDeleteButton();
        createClearDBButton();
        createAccountButtons();
        
        createButtonPanel();
        

    }
    
    // -------------------- INITIALIZATION METHODS -------------------- //

    /**
     * Sets up the main JFrame window properties.
     */

    private void initializeUI() {
        setTitle("GWA Calculator");
        setBounds(450, 190, 1014, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(255, 255, 255));
        setLayout(new BorderLayout(10, 10));
        setLocationRelativeTo(null);
        setVisible(true);
        setResizable(false);
    }
    
    /**
     * Creates the name input field at the top of the window.
     * Includes a listener to clear placeholder text when clicked.
     */

    private void createNameField(){
        nameField = new JTextField("Enter your Name: ");
        // place name field in the center panel area
        nameField.setBounds(50, 20, 400, 40);
        nameField.setFont(new Font("Serif", Font.PLAIN, 16));
        nameField.setOpaque(false);
        nameField.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, Color.BLACK));
        nameField.setForeground(Color.BLACK);

        // Clears default text when the user clicks inside the field.
        nameField.addMouseListener(new java.awt.event.MouseAdapter() {
        @Override
        public void mouseClicked(java.awt.event.MouseEvent evt) {
            if (nameField.getText().equals("Enter your Name: ")) {
                nameField.setText("");
            }
        }
    });

        centerPanel.add(nameField);
    }

    private void createDisclaimerLink() {
        // Create disclaimer button but do not add it here; it will be placed under the bottom buttons
        disclaimerLink = new JButton("<HTML><U>System Disclaimer</U></HTML>");
        disclaimerLink.setBorderPainted(false);
        disclaimerLink.setOpaque(false);
        disclaimerLink.setContentAreaFilled(false);
        disclaimerLink.setForeground(new Color(0, 102, 204));
        disclaimerLink.setFont(new Font("Serif", Font.PLAIN, 14));
        disclaimerLink.setCursor(new Cursor(Cursor.HAND_CURSOR));
        disclaimerLink.setPreferredSize(new Dimension(150, 30));
        disclaimerLink.addActionListener(e -> {
            DisclaimerDialog dlg = new DisclaimerDialog(this);
            dlg.setVisible(true);
        });
    }

    /**
     * Creates the "Compute" button and assigns an action to calculate the GWA.
     */
    
    private void createCalculateButton() {
        calculateButton = new RoundedButton("COMPUTE", new Color(255, 182, 193));
        calculateButton.setFont(new Font("Serif", Font.BOLD, 16));
        
        // Action listener triggers GWA computation
        calculateButton.addActionListener(e -> calculateGWA());
    }

    // -------------------- CORE FUNCTIONALITY -------------------- //

    /**
     * Calculates the General Weighted Average (GWA) based on input grades and units.
     * Displays an appropriate message depending on the computed GWA and grade criteria.
     */

    private void calculateGWA() {
        double totalProduct = 0;
        double totalUnits = 0;
        int validCount = 0;
        boolean hasLowGrade = false;

        // Loops through all entered grades and units.
        for (int i = 0; i < gradeFields.size(); i++) {
            try {
                String gradeText = gradeFields.get(i).getText().trim();
                String unitText = unitFields.get(i).getText().trim();

                // Skips empty rows/text fields.
                if (gradeText.isEmpty() || unitText.isEmpty()) continue;

                double grade = Double.parseDouble(gradeText);
                double unit = Double.parseDouble(unitText);

                // Multiply grade * unit (weighted score) without per-row rounding.
                totalProduct += grade * unit;
                totalUnits += unit;
                validCount++;

                // Flag if grade is considered "low".
                if (grade >= 2.4) {
                    hasLowGrade = true;
                }

            } catch (NumberFormatException e) {
                // Skip invalid entries silently.
            }
        }

        // Checks if there's an invalid input.
        if (validCount == 0) {
            JOptionPane.showMessageDialog(this,
                    "Please enter at least one valid grade and unit.",
                    "No Data Entered",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Prevents division by zero.
        if (totalUnits == 0) {
            JOptionPane.showMessageDialog(this,
                    "Total units cannot be zero.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Compute and round final GWA to two decimal places.
        double gwa = Math.round((totalProduct / totalUnits) * 100.0) / 100.0;

        // Insert student record with user_identifier so AdminDashboard can track it
        String insertStudent =
            "INSERT OR REPLACE INTO students(user_identifier, name, gwa, date) VALUES(?, ?, ?, datetime('now'));";

        try (Connection conn = Database.connect();
            PreparedStatement ps = conn.prepareStatement(insertStudent)) {

            ps.setString(1, userId); // Use the logged-in userId as user_identifier
            ps.setString(2, nameField.getText());
            ps.setDouble(3, gwa);
            ps.executeUpdate();

        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        // Insert subject records, referencing the student by user_identifier
        String insertSubject = "INSERT INTO subjects(student_user_identifier, grade, units) VALUES(?, ?, ?);";

        try (Connection conn = Database.connect()) {
            // Remove any existing subject records for this user to avoid duplicates
            try (PreparedStatement del = conn.prepareStatement("DELETE FROM subjects WHERE student_user_identifier = ?")) {
                del.setString(1, userId);
                del.executeUpdate();
            }

            try (PreparedStatement ps = conn.prepareStatement(insertSubject)) {
                for (int i = 0; i < gradeFields.size(); i++) {
                    String g = gradeFields.get(i).getText().trim();
                    String u = unitFields.get(i).getText().trim();

                    if (g.isEmpty() || u.isEmpty()) continue;

                    ps.setString(1, userId); // Reference by user_identifier
                    ps.setDouble(2, Double.parseDouble(g));
                    ps.setDouble(3, Double.parseDouble(u));
                    ps.addBatch();
                }
                ps.executeBatch();
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }


        // Predefined message templates.
        String presList = "Congratulations " + nameField.getText() + "!\n" +
                          "You made it to the President's List!" + "\n" +
                          "Your GWA is: " + gwa;

        String deansList = "Great job " + nameField.getText() + "!\n" +
                          "You made it to the Dean's List!"+ "\n" +
                          "Your GWA is: " + gwa;

        String nextTime = "Keep trying " + nameField.getText() + "!\n" +
                          "You can do it next time!"+ "\n" +
                          "Your GWA is: " + gwa;

        // Determine which list the student qualifies for.
        if (!hasLowGrade && gwa <= 1.45 && gwa >= 1.00) {
            JOptionPane.showMessageDialog(this,
                    presList,
                    "President's List",
                    JOptionPane.INFORMATION_MESSAGE);

        } else if (!hasLowGrade && gwa <= 1.75 && gwa > 1.45) {
            JOptionPane.showMessageDialog(this,
                    deansList,
                    "Dean's List",
                    JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this,
                    nextTime,
                    "No List",
                    JOptionPane.INFORMATION_MESSAGE);

        }

        // Update info label at the top right within the center panel
        if (infoLabel != null) {
            centerPanel.remove(infoLabel);
        }
        infoLabel = new JLabel(nameField.getText() + "'s " + "Final GWA: " + String.format("%.2f", gwa));
        infoLabel.setBounds(520, 20, 300, 25);
        centerPanel.add(infoLabel);
        revalidate();
        repaint();
    }

    // -------------------- PANEL AND FIELD CREATION -------------------- //
     
    /**
     * Creates the main panel that holds grade and unit text fields.
     */
    private void createPanel() {
        // Use a two-column GridLayout for Grade / Units pairs so fields flow vertically
        gradeUnitPanel = new JPanel(new GridLayout(0, 2, 10, 10));
        gradeUnitPanel.setBackground(new Color(255, 255, 255));
        gradeUnitPanel.setPreferredSize(new Dimension(220, 0)); 
        // will be added to the left (WEST) of the main panel
    }
    
    /**
     * Adds labels ("Grade" and "Units") at the top of the panel.
     */
    private void createLabels() {
        gradeLabel = new JLabel("Grade");
        gradeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        gradeLabel.setFont(new Font("Serif", Font.BOLD, 14));
        gradeUnitPanel.add(gradeLabel);

        unitLabel = new JLabel("Units");
        unitLabel.setHorizontalAlignment(SwingConstants.CENTER);
        unitLabel.setFont(new Font("Serif", Font.BOLD, 14));
        gradeUnitPanel.add(unitLabel);
    }
    
    /**
     * Generates the initial set of grade and unit input fields.
     */
    private void createTextFields() {
        // Create initial pairs of Grade / Unit fields using the GridLayout
        for (int i = 0; i < initialFieldCount; i++) {
            JTextField gradeField = new JTextField();
            gradeField.setFont(new Font("Serif", Font.PLAIN, 14));
            gradeField.setOpaque(false);
            gradeField.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.BLACK));
            gradeFields.add(gradeField);
            gradeUnitPanel.add(gradeField);

            JTextField unitField = new JTextField();
            unitField.setFont(new Font("Serif", Font.PLAIN, 14));
            unitField.setOpaque(false);
            unitField.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.BLACK));
            unitFields.add(unitField);
            gradeUnitPanel.add(unitField);
        }
    }
    
    /**
     * Creates a "+" button to add more grade and unit fields dynamically.
     */
    private void createExtraFieldButton(){

        addFieldButton = new RoundedButton("Add Row +", new Color(173, 216, 230));
        addFieldButton.setFont(new Font("Serif", Font.BOLD, 16));
        
        addFieldButton.addActionListener(e -> createExtraField());
    }
    
    /**
     * Dynamically adds an extra grade and unit text field pair.
     */
    private void createExtraField() {
        
        if (initialFieldCount >= MAX_FIELDS) {
            JOptionPane.showMessageDialog(this,
                    "You can only add up to " + MAX_FIELDS + " subjects",
                    "Limit Reached", 
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        JTextField newGradeField = new JTextField();
        newGradeField.setFont(new Font("Serif", Font.PLAIN, 14));
        newGradeField.setOpaque(false);
        newGradeField.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.BLACK));
        gradeFields.add(newGradeField);
        addedGradeFields.add(newGradeField);
        gradeUnitPanel.add(newGradeField);

        JTextField newUnitField = new JTextField();
        newUnitField.setFont(new Font("Serif", Font.PLAIN, 14));
        newUnitField.setOpaque(false);
        newUnitField.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.BLACK));
        unitFields.add(newUnitField);
        addedUnitFields.add(newUnitField);
        gradeUnitPanel.add(newUnitField);

        gradeUnitPanel.revalidate();
        gradeUnitPanel.repaint();
        initialFieldCount++;
    }

    /**
     * Creates a "-" button to remove the most recently added subject fields.
     */
    private void createMinusButton() {
        
        minusButton = new RoundedButton("Remove Row -", new Color(255, 182, 193));
        minusButton.setFont(new Font("Serif", Font.BOLD, 16));

        minusButton.addActionListener(e -> removeLastField());
    }

    /**
     * Removes the last dynamically added grade and unit fields pair.
     */
    private void removeLastField() {
    if (!addedGradeFields.isEmpty() && !addedUnitFields.isEmpty()) {
        JTextField lastGrade = addedGradeFields.remove(addedGradeFields.size() - 1);
        JTextField lastUnit = addedUnitFields.remove(addedUnitFields.size() - 1);

        gradeFields.remove(lastGrade);
        unitFields.remove(lastUnit);

        gradeUnitPanel.remove(lastGrade);
        gradeUnitPanel.remove(lastUnit);

        initialFieldCount--;

        gradeUnitPanel.revalidate();
        gradeUnitPanel.repaint();

    } else {
        JOptionPane.showMessageDialog(this,
                "Minimum number of fields reached!",
                "Nothing to Delete",
                JOptionPane.INFORMATION_MESSAGE);
        }
    }

    /**
     * Creates the "Clear" button that resets all text fields for the grade and unit.
     */
    private void createClearButton() {
        clearButton = new RoundedButton("CLEAR", new Color(173, 216, 230));
        clearButton.setFont(new Font("Serif", Font.BOLD, 16));
        clearButton.addActionListener(e -> clearAllFields());
    }

    /**
     * Clears all grade and unit input fields and information label on frame.
     */
    private void clearAllFields() {
        gradeFields.stream().forEach((g) -> {
            g.setText("");
        });
        unitFields.stream().forEach((u) -> {
            u.setText("");
        });
        infoLabel.setText("");
    }
    
    private void exportToTxt() {

        String filePath = "gwa_records.txt";

        String studentQuery =
            "SELECT id, name, gwa, date FROM students;"
        ;

        String subjectQuery = 
            "SELECT grade, units FROM subjects WHERE student_id = ?;"
        ;

        try (
            BufferedWriter writer = new BufferedWriter(new FileWriter(filePath));
            Connection conn = Database.connect();
            PreparedStatement studentPS = conn.prepareStatement(studentQuery);
            ResultSet studentRS = studentPS.executeQuery()
        ) {

            writer.write("GWA RECORDS");
            writer.newLine();
            writer.write("====================");
            writer.newLine();

            while (studentRS.next()) {

                int studentId = studentRS.getInt("id");

                writer.write("Name: " + studentRS.getString("name"));
                writer.newLine();
                writer.write("GWA: " + studentRS.getDouble("gwa"));
                writer.newLine();
                writer.write("Date: " + studentRS.getString("date"));
                writer.newLine();
                writer.write("Subjects:");
                writer.newLine();

                try (PreparedStatement subjectPS = conn.prepareStatement(subjectQuery)) {
                    subjectPS.setInt(1, studentId);
                    ResultSet subjectRS = subjectPS.executeQuery();

                    while (subjectRS.next()) {
                        writer.write("  Grade: " + subjectRS.getDouble("grade")
                               + " | Units: " + subjectRS.getDouble("units"));
                        writer.newLine();
                    }
                }

                writer.newLine();
                writer.write("--------------------");
                writer.newLine();
            }

            JOptionPane.showMessageDialog(this,
                    "Data exported successfully to gwa_records.txt",
                    "Export Complete",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (IOException | SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Export failed: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    private void createExportButton() {
        exportButton = new RoundedButton("EXPORT", new Color(255, 182, 193));
        exportButton.setFont(new Font("Serif", Font.BOLD, 16));
        exportButton.addActionListener(e -> exportToTxt());
    }
    private void viewRecords() {

        String query = "SELECT id, name, gwa, date FROM students";

        StringBuilder output = new StringBuilder("SAVED RECORDS\n\n");

        try (Connection conn = Database.connect();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
            output.append("ID: ").append(rs.getInt("id")).append("\n");
            output.append("Name: ").append(rs.getString("name")).append("\n");
            output.append("GWA: ").append(rs.getDouble("gwa")).append("\n");
            output.append("Date: ").append(rs.getString("date")).append("\n");
            output.append("---------------------\n");
            }

            JOptionPane.showMessageDialog(this, output.toString(),
                    "Database Records", JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Error loading records",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    private void createViewButton() {
        viewButton = new RoundedButton("VIEW RECORDS", new Color(173, 216, 230));
        viewButton.setFont(new Font("Serif", Font.BOLD, 16));
        viewButton.addActionListener(e -> viewRecords());
    }
    private void deleteByName() {

        String name = JOptionPane.showInputDialog(this,
                "Enter student name to delete:");

        if (name == null || name.trim().isEmpty()) return;

        String getIdQuery = "SELECT id FROM students WHERE name = ?";
        String deleteSubjects = "DELETE FROM subjects WHERE student_id = ?";
        String deleteStudent = "DELETE FROM students WHERE id = ?";

        try (Connection conn = Database.connect();
            PreparedStatement ps = conn.prepareStatement(getIdQuery)) {

            ps.setString(1, name);
            ResultSet rs = ps.executeQuery();

            if (!rs.next()) {
                JOptionPane.showMessageDialog(this,
                        "No record found for that name.",
                        "Not Found",
                        JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            int studentId = rs.getInt("id");

            try (PreparedStatement ps1 = conn.prepareStatement(deleteSubjects);
                PreparedStatement ps2 = conn.prepareStatement(deleteStudent)) {

                ps1.setInt(1, studentId);
                ps1.executeUpdate();

                ps2.setInt(1, studentId);
                ps2.executeUpdate();
            }

            JOptionPane.showMessageDialog(this,
                    "Record deleted successfully.",
                    "Deleted",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Delete failed.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    private void createDeleteButton() {
        deleteButton = new RoundedButton("DELETE RECORD", new Color(255, 182, 193));
        deleteButton.setFont(new Font("Serif", Font.BOLD, 16));
        deleteButton.addActionListener(e -> deleteByName());
    }
    private void deleteAllData() {

        int confirm = JOptionPane.showConfirmDialog(this,
            "This will delete ALL records.\nAre you sure?",
            "Confirm Delete",
            JOptionPane.YES_NO_OPTION);

        if (confirm != JOptionPane.YES_OPTION) return;

        try (Connection conn = Database.connect();
            Statement stmt = conn.createStatement()) {

            stmt.executeUpdate("DELETE FROM subjects");
            stmt.executeUpdate("DELETE FROM students");

            JOptionPane.showMessageDialog(this,
                    "All records deleted.",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Failed to delete records.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    private void createClearDBButton() {

        JButton clearDBButton = new RoundedButton("CLEAR DATABASE", new Color(173, 216, 230));
        clearDBButton.setFont(new Font("Serif", Font.BOLD, 16));
        clearDBButton.addActionListener(e -> deleteAllData());
    }
    private void createAccountButtons() {
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        topPanel.setBackground(new Color(255, 255, 255));

        changePasswordButton = new RoundedButton("CHANGE PASSWORD", new Color(255, 182, 193));
        changePasswordButton.setFont(new Font("Serif", Font.BOLD, 14));
        logOutButton = new RoundedButton("LOGOUT", new Color(173, 216, 230));
        logOutButton.setFont(new Font("Serif", Font.BOLD, 14));

        changePasswordButton.addActionListener(e -> {
            ChangePassword cp = new ChangePassword(userId);
            cp.setTitle("Change Password");
            cp.setVisible(true);
        });

        logOutButton.addActionListener(e -> {
            dispose();           // close GWA window
            mainMenu.setVisible(true);  // show main menu again
        });

        topPanel.add(changePasswordButton);
        topPanel.add(logOutButton);

        add(topPanel, BorderLayout.NORTH);
    }
    
    private void loadSubjectsFromDB() {
    String sql = "SELECT grade, units FROM subjects WHERE student_user_identifier = ?";
    try (Connection conn = Database.connect();
         PreparedStatement ps = conn.prepareStatement(sql)) {

        ps.setString(1, userId);
        ResultSet rs = ps.executeQuery();

        int i = 0;
        while (rs.next()) {
            if (i >= gradeFields.size()) {
                createExtraField();
            }
            gradeFields.get(i).setText(String.valueOf(rs.getDouble("grade")));
            unitFields.get(i).setText(String.valueOf(rs.getDouble("units")));
            i++;
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }
}
    
    private void dataPanel() {
        // Wrap the grade/unit panel with padding to prevent it from sticking to the edge
        JPanel paddedGradePanel = new JPanel(new BorderLayout());
        paddedGradePanel.setBackground(new Color(255, 255, 255));
        paddedGradePanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 10));
        paddedGradePanel.add(gradeUnitPanel, BorderLayout.CENTER);
        
        // put the grade/unit panel on the left side for a landscape layout
        mainPanel.add(paddedGradePanel, BorderLayout.WEST);
    }
    
    private void createButtonPanel() {
    JPanel bottomPanel = new JPanel(new GridLayout(2, 4, 10, 10));
    bottomPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    bottomPanel.setBackground(new Color(255, 255, 255));

    bottomPanel.add(calculateButton);
    bottomPanel.add(clearButton);
    bottomPanel.add(minusButton);
    bottomPanel.add(addFieldButton);

    bottomPanel.add(new JLabel()); // spacer
    bottomPanel.add(new JLabel()); // spacer
    bottomPanel.add(new JLabel()); // spacer
    // Place disclaimer button under the four main buttons at bottom-right
    bottomPanel.add(disclaimerLink != null ? disclaimerLink : new JLabel());

    add(bottomPanel, BorderLayout.SOUTH);
}
    
    private void createMainPanel() {
        // Use a BorderLayout so we can place the grade/unit panel on the left
        // and the rest of the inputs in the center (landscape-friendly)
        mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBackground(new Color(255, 255, 255));

        // centerPanel will host nameField, infoLabel and any extra controls
        centerPanel = new JPanel(null);
        centerPanel.setBackground(new Color(255, 255, 255));

        // Add gradient header at the top left corner, just above the grade/unit labels
        GradientHeader header = new GradientHeader();
        header.setPreferredSize(new Dimension(400, 70));
        JLabel hdrLabel = new JLabel("STUDENT DASHBOARD");
        hdrLabel.setFont(new Font("Serif", Font.BOLD, 24));
        hdrLabel.setHorizontalAlignment(SwingConstants.CENTER);
        hdrLabel.setForeground(Color.BLACK);
        hdrLabel.setBounds(0, 0, 400, 70);
        header.setLayout(null);
        header.add(hdrLabel);

        JPanel topContainer = new JPanel(new BorderLayout());
        topContainer.setBorder(BorderFactory.createEmptyBorder(15, 15, 10, 10));
        topContainer.setOpaque(false);
        topContainer.add(header, BorderLayout.WEST);
        mainPanel.add(topContainer, BorderLayout.NORTH);

        add(mainPanel, BorderLayout.CENTER);
        mainPanel.add(centerPanel, BorderLayout.CENTER);
    }
    
    private String fetchNameFromDB(String userId) {
        String query = "SELECT name FROM users WHERE user_identifier = ?";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, userId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getString("name");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Failed to fetch user name: " + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE);
        }
        return null; // if not found
    }

    // Modal disclaimer dialog with gradient rounded background and Proceed/Exit buttons
    private class GradientHeader extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth();
            int h = getHeight();
            GradientPaint gp = new GradientPaint(0, 0, new Color(255, 182, 193), w, 0, new Color(173, 216, 230));
            g2.setPaint(gp);
            g2.fillRoundRect(0, 0, w, h, 15, 15);
            g2.setColor(Color.BLACK);
            g2.setStroke(new BasicStroke(2));
            g2.drawRoundRect(0, 0, w - 1, h - 1, 15, 15);
        }
    }

    private class RoundedButton extends JButton {
        private final Color baseColor;

        RoundedButton(String text, Color baseColor) {
            super(text);
            this.baseColor = baseColor;
            setContentAreaFilled(false);
            setFocusPainted(false);
            setBorderPainted(false);
            setForeground(Color.BLACK);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth();
            int h = getHeight();
            GradientPaint gp = new GradientPaint(0, 0, baseColor.darker(), w, h, baseColor.brighter());
            g2.setPaint(gp);
            g2.fillRoundRect(0, 0, w, h, h / 2, h / 2);
            g2.setColor(Color.BLACK);
            g2.setStroke(new BasicStroke(2));
            g2.drawRoundRect(0, 0, w - 1, h - 1, h / 2, h / 2);
            g2.dispose();
            super.paintComponent(g);
        }

        @Override
        public boolean isOpaque() {
            return false;
        }
    }

    // Modal disclaimer dialog with gradient rounded background and Proceed/Exit buttons
    private class DisclaimerDialog extends JDialog {
        public DisclaimerDialog(JFrame parent) {
            super(parent, "System Disclaimer", true);
            setSize(720, 460);
            setResizable(false);
            setLocationRelativeTo(parent);

            GradientPanel content = new GradientPanel();
            content.setLayout(null);
            content.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

            JLabel title = new JLabel("SYSTEM DISCLAIMER!!!");
            title.setFont(new Font("Serif", Font.BOLD, 28));
            title.setHorizontalAlignment(SwingConstants.CENTER);
            title.setBounds(20, 10, 680, 40);
            content.add(title);

            String htmlText = "<html><div style='font-size:16px; padding:10px; line-height:1.4;'>"
                    + "<b>This GWA Calculator follows the official Bicol University Grading Scale (1.0 - 5.0).</b> Computed Results depend on the accuracy of the grades provided by the <span style='color:#0645AD;'>user</span>.<br><br>"
                    + "By clicking <span style='color:#0645AD; font-weight:bold;'>\"Proceed\"</span>, you agree to use the system responsibly.";

            JLabel text = new JLabel(htmlText);
            text.setBounds(40, 70, 640, 260);
            text.setFont(new Font("Serif", Font.PLAIN, 18));
            content.add(text);

            JButton proceed = new JButton("PROCEED");
            proceed.setBounds(200, 350, 120, 50);
            proceed.setBackground(new Color(255, 182, 193));
            proceed.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2, true));
            proceed.addActionListener(e -> dispose());
            content.add(proceed);

            JButton exitBtn = new JButton("EXIT");
            exitBtn.setBounds(400, 350, 120, 50);
            exitBtn.setBackground(new Color(173, 216, 230));
            exitBtn.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2, true));
            exitBtn.addActionListener(e -> System.exit(0));
            content.add(exitBtn);

            setContentPane(content);
        }

        // Panel that paints a rounded gradient background
        private class GradientPanel extends JPanel {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int w = getWidth();
                int h = getHeight();
                GradientPaint gp = new GradientPaint(0, 0, new Color(255, 182, 193), w, h, new Color(173, 216, 230));
                g2.setPaint(gp);
                g2.fillRoundRect(8, 8, w - 16, h - 16, 30, 30);
                g2.setColor(Color.BLACK);
                g2.setStroke(new BasicStroke(3));
                g2.drawRoundRect(8, 8, w - 16, h - 16, 30, 30);
            }
        }
    }
}