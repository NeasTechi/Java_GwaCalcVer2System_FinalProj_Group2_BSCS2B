package gwacalculator;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import gwacalculator.Database;

public class UserRegistration extends JFrame {

    private MainMenu mainMenu;
    private JTextField firstname;
    private JTextField userID;
    private JPasswordField passwordField;

    public UserRegistration(MainMenu menu) {
        this.mainMenu = menu;

        setTitle("Register New User");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(450, 190, 1014, 597);
        setResizable(false);

        JPanel contentPane = new JPanel(null);
        contentPane.setBackground(new Color(255, 255, 255));
        setContentPane(contentPane);

        // Rounded gradient header
        GradientHeader header = new GradientHeader();
        header.setBounds(20, 10, 960, 70);
        JLabel hdrLabel = new JLabel("GWA CALCULATOR SYSTEM");
        hdrLabel.setFont(new Font("Serif", Font.BOLD, 28));
        hdrLabel.setHorizontalAlignment(SwingConstants.CENTER);
        hdrLabel.setForeground(Color.BLACK);
        hdrLabel.setBounds(0, 0, 960, 70);
        header.setLayout(null);
        header.add(hdrLabel);
        contentPane.add(header);

        JLabel lblName = new JLabel("First Name:");
        lblName.setFont(new Font("Serif", Font.BOLD, 24));
        lblName.setBounds(80, 120, 200, 40);
        contentPane.add(lblName);

        firstname = new JTextField();
        firstname.setFont(new Font("Serif", Font.PLAIN, 20));
        firstname.setBounds(300, 125, 660, 36);
        firstname.setOpaque(false);
        firstname.setBorder(BorderFactory.createMatteBorder(0, 0, 3, 0, Color.BLACK));
        contentPane.add(firstname);

        JLabel lblID = new JLabel("User ID:");
        lblID.setFont(new Font("Serif", Font.BOLD, 24));
        lblID.setBounds(80, 180, 200, 40);
        contentPane.add(lblID);

        userID = new JTextField();
        userID.setFont(new Font("Serif", Font.PLAIN, 20));
        userID.setBounds(300, 185, 660, 36);
        userID.setOpaque(false);
        userID.setBorder(BorderFactory.createMatteBorder(0, 0, 3, 0, Color.BLACK));
        contentPane.add(userID);

        JLabel lblPassword = new JLabel("Password:");
        lblPassword.setFont(new Font("Serif", Font.BOLD, 24));
        lblPassword.setBounds(80, 240, 200, 40);
        contentPane.add(lblPassword);

        passwordField = new JPasswordField();
        passwordField.setFont(new Font("Serif", Font.PLAIN, 20));
        passwordField.setBounds(300, 245, 660, 36);
        passwordField.setOpaque(false);
        passwordField.setBorder(BorderFactory.createMatteBorder(0, 0, 3, 0, Color.BLACK));
        contentPane.add(passwordField);

        RoundedButton backButton = new RoundedButton("BACK", new Color(255, 182, 193));
        backButton.setFont(new Font("Serif", Font.BOLD, 20));
        backButton.setBounds(300, 330, 180, 60);
        backButton.addActionListener(e -> {
            this.dispose();
            mainMenu.setVisible(true);
        });
        contentPane.add(backButton);

        RoundedButton btnRegister = new RoundedButton("REGISTER", new Color(173, 216, 230));
        btnRegister.setFont(new Font("Serif", Font.BOLD, 20));
        btnRegister.setBounds(520, 330, 180, 60);
        btnRegister.addActionListener(e -> registerUser());
        contentPane.add(btnRegister);
    }

    private void registerUser() {
        String firstName = firstname.getText().trim();
        String id = userID.getText().trim();
        String password = new String(passwordField.getPassword()).trim();

        if (firstName.isEmpty() || id.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Fill in all fields");
            return;
        }

        String role = id.startsWith("A-") ? "admin" : "student";

        try (Connection conn = Database.connect()) {
            String query = "INSERT INTO users(user_identifier, name, password, role) VALUES(?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, id);
            ps.setString(2, firstName);
            ps.setString(3, password);
            ps.setString(4, role);
            ps.executeUpdate();

            // If student, create empty student record
            if (role.equals("student")) {
                Database.addStudentRecord(id, firstName);
            }

            JOptionPane.showMessageDialog(this, "Welcome, " + firstName + "! Account created as " + role);
            this.dispose();
            mainMenu.setVisible(true);

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to register user: " + e.getMessage());
        }
    }

    // Rounded gradient header panel
    private static class GradientHeader extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth();
            int h = getHeight();
            GradientPaint gp = new GradientPaint(0, 0, new Color(255, 182, 193), w, 0, new Color(173, 216, 230));
            g2.setPaint(gp);
            g2.fillRoundRect(0, 0, w, h, h, h);
            g2.setColor(Color.BLACK);
            g2.setStroke(new BasicStroke(2));
            g2.drawRoundRect(0, 0, w - 1, h - 1, h, h);
        }
    }

    // Simple rounded button with flat gradient fill
    private static class RoundedButton extends JButton {
        private final Color base;
        RoundedButton(String text, Color base) {
            super(text);
            this.base = base;
            setContentAreaFilled(false);
            setFocusPainted(false);
            setBorderPainted(false);
            setForeground(Color.BLACK);
        }
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth();
            int h = getHeight();
            GradientPaint gp = new GradientPaint(0, 0, base.darker(), w, h, base.brighter());
            g2.setPaint(gp);
            g2.fillRoundRect(0, 0, w, h, h/2, h/2);
            g2.setColor(Color.BLACK);
            g2.setStroke(new BasicStroke(2));
            g2.drawRoundRect(0, 0, w-1, h-1, h/2, h/2);
            g2.dispose();
            super.paintComponent(g);
        }
        @Override
        public void setForeground(Color fg) {
            super.setForeground(fg);
        }
        @Override
        public boolean isOpaque() { return false; }
    }
}
