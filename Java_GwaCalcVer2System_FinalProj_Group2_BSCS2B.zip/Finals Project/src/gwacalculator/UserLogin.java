package gwacalculator;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import gwacalculator.Database;
import gwacalculator.AdminDashboard;

public class UserLogin extends JFrame {
    private MainMenu mainMenu;
    private JTextField textField;
    private JPasswordField passwordField;

    public UserLogin(MainMenu menu) {
        this.mainMenu = menu;

        setTitle("Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(450, 190, 1014, 597);
        setResizable(false);
        
        JPanel contentPane = new JPanel(null);
        contentPane.setBackground(new Color(255,255,255));
        setContentPane(contentPane);

        // Rounded gradient header like the example image
        GradientHeader header = new GradientHeader();
        header.setBounds(20, 10, 960, 70);
        JLabel hdrLabel = new JLabel("GWA CALCULATOR SYSTEM");
        hdrLabel.setFont(new Font("Serif", Font.BOLD, 28));
        hdrLabel.setHorizontalAlignment(SwingConstants.CENTER);
        hdrLabel.setForeground(Color.BLACK);
        hdrLabel.setBounds(0, 0, 960, 70);
        header.setLayout(null);
        header.add(hdrLabel);
        contentPane.add(header);

        JLabel lblUsername = new JLabel("User ID:");
        lblUsername.setFont(new Font("Serif", Font.BOLD, 26));
        lblUsername.setBounds(80, 120, 200, 40);
        contentPane.add(lblUsername);

        textField = new JTextField();
        textField.setFont(new Font("Serif", Font.PLAIN, 20));
        textField.setBounds(300, 125, 580, 36);
        textField.setOpaque(false);
        textField.setBorder(BorderFactory.createMatteBorder(0, 0, 3, 0, Color.BLACK));
        contentPane.add(textField);

        JLabel lblPassword = new JLabel("Password:");
        lblPassword.setFont(new Font("Serif", Font.BOLD, 26));
        lblPassword.setBounds(80, 200, 200, 40);
        contentPane.add(lblPassword);

        passwordField = new JPasswordField();
        passwordField.setFont(new Font("Serif", Font.PLAIN, 20));
        passwordField.setBounds(300, 205, 580, 36);
        passwordField.setOpaque(false);
        passwordField.setBorder(BorderFactory.createMatteBorder(0, 0, 3, 0, Color.BLACK));
        contentPane.add(passwordField);

        // Custom rounded buttons to match header aesthetics
        RoundedButton backButton = new RoundedButton("BACK", new Color(255, 182, 193));
        backButton.setFont(new Font("Serif", Font.BOLD, 20));
        backButton.setBounds(300, 300, 180, 60);
        backButton.addActionListener(e -> {
            this.dispose();
            mainMenu.setVisible(true);
        });
        contentPane.add(backButton);

        RoundedButton btnLogin = new RoundedButton("LOGIN", new Color(173, 216, 230));
        btnLogin.setFont(new Font("Serif", Font.BOLD, 20));
        btnLogin.setBounds(520, 300, 180, 60);
        btnLogin.addActionListener(e -> loginAction());
        contentPane.add(btnLogin);
    }

    private void loginAction() {
        String userId = textField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();

        if (userId.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter both User ID and Password");
            return;
        }

        String query = "SELECT name, role FROM users WHERE user_identifier = ? AND password = ?";
        try (Connection conn = Database.connect();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, userId);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String name = rs.getString("name");
                String role = rs.getString("role");

                dispose();

                if (role.equals("admin")) {
                    JOptionPane.showMessageDialog(this, "Admin login successful");
                    AdminDashboard admin = new AdminDashboard(userId);
                    admin.setVisible(true);
                } else {
                    GwaCalculator studentGWA = new GwaCalculator(userId, mainMenu);
                    studentGWA.setTitle("GWA Calculator - " + name);
                    studentGWA.setVisible(true);
                }

            } else {
                JOptionPane.showMessageDialog(this, "Wrong User ID or Password");
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Login failed: " + ex.getMessage());
        }
    }

    // Rounded gradient header panel
    private static class GradientHeader extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth();
            int h = getHeight();
            GradientPaint gp = new GradientPaint(0, 0, new Color(255, 182, 193), w, 0, new Color(173, 216, 230));
            g2.setPaint(gp);
            g2.fillRoundRect(0, 0, w, h, h, h);
            g2.setColor(Color.BLACK);
            g2.setStroke(new BasicStroke(2));
            g2.drawRoundRect(0, 0, w - 1, h - 1, h, h);
        }
    }

    // Simple rounded button with flat gradient fill
    private static class RoundedButton extends JButton {
        private final Color base;
        RoundedButton(String text, Color base) {
            super(text);
            this.base = base;
            setContentAreaFilled(false);
            setFocusPainted(false);
            setBorderPainted(false);
            setForeground(Color.BLACK);
        }
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth();
            int h = getHeight();
            GradientPaint gp = new GradientPaint(0, 0, base.darker(), w, h, base.brighter());
            g2.setPaint(gp);
            g2.fillRoundRect(0, 0, w, h, h/2, h/2);
            g2.setColor(Color.BLACK);
            g2.setStroke(new BasicStroke(2));
            g2.drawRoundRect(0, 0, w-1, h-1, h/2, h/2);
            g2.dispose();
            super.paintComponent(g);
        }
        @Override
        public void setForeground(Color fg) {
            super.setForeground(fg);
        }
        @Override
        public boolean isOpaque() { return false; }
    }
}
