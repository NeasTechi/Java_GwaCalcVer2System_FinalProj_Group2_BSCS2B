package gwacalculator;

import java.sql.*;
import java.util.ArrayList;
import java.io.BufferedWriter;
import java.io.FileWriter;

public class ExportTest {
    public static void main(String[] args) {
        try (Connection conn = Database.connect()) {
            String query = "SELECT user_identifier, name, date FROM students ORDER BY date DESC";
            ArrayList<String[]> rows = new ArrayList<>();
            int idW = "Student ID".length();
            int nameW = "Name".length();
            int gwaW = "GWA".length();
            int dateW = "Date".length();

            try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
                while (rs.next()) {
                    String studentId = rs.getString("user_identifier");
                    String name = rs.getString("name");
                    String date = rs.getString("date");

                    // compute gwa for this student
                    double total = 0, units = 0;
                    try (PreparedStatement ps = conn.prepareStatement("SELECT grade, units FROM subjects WHERE student_id=?")) {
                        ps.setString(1, studentId);
                        try (ResultSet rs2 = ps.executeQuery()) {
                            while (rs2.next()) {
                                double grade = rs2.getDouble("grade");
                                double u = rs2.getDouble("units");
                                total += grade * u;
                                units += u;
                            }
                        }
                    }
                    double gwaVal = units == 0 ? 0 : Math.round(total / units * 100.0) / 100.0;

                    String idStr = studentId == null ? "" : studentId;
                    String nameStr = name == null ? "" : name;
                    String gwaStr = String.format("%.2f", gwaVal);
                    String dateStr = date == null ? "" : date;

                    rows.add(new String[]{idStr, nameStr, gwaStr, dateStr});

                    idW = Math.max(idW, idStr.length());
                    nameW = Math.max(nameW, nameStr.length());
                    gwaW = Math.max(gwaW, gwaStr.length());
                    dateW = Math.max(dateW, dateStr.length());
                }
            }

            System.out.println("Found rows: " + rows.size());
            for (String[] r : rows) {
                System.out.println(String.join(" | ", r));
            }

            String fmt = String.format("%%-%ds  %%-%ds  %%-%ds  %%-%ds%n", idW, nameW, gwaW, dateW);
            try (BufferedWriter writer = new BufferedWriter(new FileWriter("admin_student_records_test.txt"))) {
                writer.write(String.format(fmt, "Student ID", "Name", "GWA", "Date"));
                for (String[] r : rows) writer.write(String.format(fmt, r[0], r[1], r[2], r[3]));
            }

            System.out.println("Wrote admin_student_records_test.txt");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
